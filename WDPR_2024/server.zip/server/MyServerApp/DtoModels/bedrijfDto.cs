namespace WDPR_2024.server.MyServerApp.DtoModels;

public class BedrijfDto
{
    public int BedrijfID { get; set; }
    public string Bedrijfsnaam { get; set; }
    public string Adres { get; set; }
    public string KVKNummer { get; set; }
    public string EmailDomein { get; set; }
    public string ContactEmail { get; set; }
    public string Password { get; set; }

}
