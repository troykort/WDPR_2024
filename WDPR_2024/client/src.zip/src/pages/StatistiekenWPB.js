import React from 'react';

const StatistiekenWPB = () => {
    return (
        <div>
            <h1>Statistieken WPB</h1>
        </div>
    );
};

export default StatistiekenWPB;
