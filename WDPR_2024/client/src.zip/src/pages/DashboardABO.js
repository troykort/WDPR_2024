﻿import React from 'react';

const DashboardABO = () => {
    return (
        <div>
            <h1>Dashboard Abonnementbeheerder</h1>
            {/* Voeg hier de inhoud van het dashboard toe */}
        </div>
    );
};

export default DashboardABO;
