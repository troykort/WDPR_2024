﻿import React from 'react';

const DashboardParticulier = () => {
    return (
        <div>
            <h1>Dashboard Particulier</h1>
            {/* Voeg hier de inhoud van het dashboard toe */}
        </div>
    );
};

export default DashboardParticulier;
