import React from 'react';

const ProfielWPB = () => {
    return (
        <div>
            <h1>Profiel WPB</h1>
            {/* Voeg hier je statistieken inhoud toe */}
        </div>
    );
};

export default ProfielWPB;