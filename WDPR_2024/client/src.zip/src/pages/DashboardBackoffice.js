﻿import React from "react";

const DashboardBackoffice = () => {
    return (
        <div>
            <h1>Dashboard Backoffice</h1>
           
        </div>
    );
};

export default DashboardBackoffice;